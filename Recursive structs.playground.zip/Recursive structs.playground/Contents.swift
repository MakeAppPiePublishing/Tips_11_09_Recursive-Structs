// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 11 (Q3 2020) video 09
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Learn the secret to building recursive structs, the model pattern for using the outline view in SwiftUI. 
//  For more code, go to http://bit.ly/AppPieGithub

import SwiftUI
struct MyModel:Identifiable{
    var id:Int
    var title:String{"id = \(id)"}
    var children:[MyModel]? = nil
}

var myModel = MyModel(id:0,
  children:[
    MyModel(id:1, children:[MyModel(id:11),MyModel(id:12)]),
    MyModel(id:2,children:[MyModel(id:21),MyModel(id:22)])
    ]
)

func printOutline(model:MyModel, level:Int = 0){
    if let children = model.children{
        for child in children{
            printOutline(model: child, level: level + 1)
        }
    }
    print(String(repeating:"\t",count:level) + "->" + model.title + "Level:\(level)")
}

printOutline(model:myModel)
